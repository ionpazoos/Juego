export default class Camara
{
    constructor(x,y)
    {
        this.x = x;
        this.y = y;
    }
}