export default class HitBox
{

    constructor(xSize, ySize, xOffset, yOffset){
        this.xSize = xSize;
        this.ySize = ySize;
        this.xOffset = xOffset;
        this.yOffset = yOffset;
    }
}